from random import randint

import pygame

try:
    import pgzrun
    from pgzero.actor import Actor
except ImportError:
    class DummyPgzRun:
        def go(self): pass
    pgzrun = DummyPgzRun()

WIDTH=550
HEIGHT=600
height=randint(140, 420)
h=70
w=50
speed = 2
up=False
game_over=False
score=0
bird=Actor("flapbird.png")
pole=Actor("pole.png")
pole1 = Actor("pole.png")
pole2 = Actor("pole.png")
pole3 = Actor("pole.png")
coin = Actor("coin.png")
coin1 = Actor("coin.png")
gap = randint(250, 270)
coin_collected = False
coin1_collected = False
restart = False
start = True

def setup():
    global coin_collected, coin1_collected, up, game_over, score, pole, pole1, pole2, pole3, gap

    bird._surf = pygame.transform.scale(bird._surf, (h, w))
    bird.pos=200, 200
    bird._update_pos()

    pole._surf = pygame.transform.scale(pole._surf, (100, 500))
    pole._update_pos()

    pole1.angle = 180
    pole1._surf = pygame.transform.scale(pole1._surf, (100, 500))
    pole1._update_pos()

    pole2._surf = pygame.transform.scale(pole._surf, (100, 500))
    pole2._update_pos()

    pole3.angle = 180
    pole3._surf = pygame.transform.scale(pole1._surf, (100, 500))
    pole3._update_pos()

    gap = randint(250, 270)
    pole.pos = 650, HEIGHT - height
    pole1.pos = 650, pole.y - gap - pole1.height

    gap = randint(250, 270)
    pole2.pos = 1700, HEIGHT - height
    pole3.pos = 1700, pole2.y - gap - pole3.height

    coin.pos = (700, (pole1.bottom + pole.top) // 2)
    coin_collected = False

    coin1.pos = (1750, (pole3.bottom + pole2.top) // 2)
    coin1_collected = False
    
    up=False
    game_over=False
    score=0

def draw():
    global restart
    screen.blit("background.png", (0,0))
    if restart:
        setup()
        restart = False
    if start:
        screen.draw.text(
            "Flappy Bird",
            center=(WIDTH // 2, HEIGHT // 2 -50),
            fontsize=60,
            color="black")
        screen.draw.text(
            "Press space to jump, start,"
            "\n and restart the game"
            "\n Hold space to glide",
            center=(WIDTH // 2, HEIGHT // 2 + 50),
            fontsize=60,
            color="black")

    elif not game_over:
        bird.draw()
        pole.draw()
        pole1.draw()
        pole2.draw()
        pole3.draw()
        if not coin_collected:
            coin.draw()
        if not coin1_collected:
            coin1.draw()
        screen.draw.text("Score: " + str(score), (420,5), color="black")
    else:
        screen.draw.text(
            "GAME OVER",
            center=(WIDTH // 2, HEIGHT // 2 - 50),
            fontsize=60,
            color="black")
        screen.draw.text(
            "Your score was: " + str(score),
            center=(WIDTH // 2, HEIGHT // 2),
            fontsize=60,
            color="black"
        )
        screen.draw.text(
            "Press space to try again",
            center=(WIDTH // 2, HEIGHT // 2+50),
            fontsize=60,
            color="black")

def on_key_down(key):
    if key == keys.SPACE:
        global up
        up=True
        bird.y -= 70
        bird._surf = pygame.transform.scale(bird._surf, (h, w))
        bird._update_pos()

def on_key_up(key):
    global restart, start, game_over
    if key == keys.SPACE:
        if start == True or game_over == True:
            restart = True
            start = False
            draw()
        else:
            global up
            up=False
            bird._surf = pygame.transform.scale(bird._surf, (h, w))
            bird._update_pos()


def update():
    global game_over, score, coin_collected, coin1_collected, height, speed, start

    if start:
        return
    if not game_over:

        if not up:
            bird.y += 5

        pole.x -= speed
        pole1.x -= speed
        pole2.x -= speed
        pole3.x -= speed
        coin.x -= speed
        coin1.x -= speed

        if pole.right < 0:

            height = randint(170, 420)

            pole.pos = 650, HEIGHT - height
            pole1.pos = 650, pole.y - gap - pole1.height

            if (pole1.bottom < 0):
                coin.pos = (700, gap // 2)
            else:
                coin.pos = (700, (pole1.bottom + pole.top) // 2)

            coin_collected = False

        if pole2.right < 0:
            height = randint(170, 420)

            pole2.pos = 650, HEIGHT - height
            pole3.pos = 650, pole2.y - gap - pole3.height

            if (pole3.bottom < 0):
                coin1.pos = (700, gap // 2)
            else:
                coin1.pos = (700, (pole3.bottom + pole2.top) // 2)

            coin1_collected = False

        if not coin_collected and bird.colliderect(coin):
            coin_collected = True
            score += 1

        if not coin1_collected and bird.colliderect(coin1):
            coin1_collected = True
            score += 1

        if bird.y < 0 or bird.y > 600:
            game_over = True

        if bird.colliderect(pole) or bird.colliderect(pole1) or bird.colliderect(pole2) or bird.colliderect(pole3):
            game_over = True

pgzrun.go()