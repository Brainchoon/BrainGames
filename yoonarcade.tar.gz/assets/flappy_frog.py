import pygame
import pgzrun
from pgzero.actor import Actor
from pgzero.keyboard import keyboard

WIDTH = 10000
HEIGHT = 500
floors = []
score = 0
scroll_x = 0
gamepart = 1

frog = Actor("frog.png")
frog._surf = pygame.transform.scale(frog._surf, (100,  60))
frog._update_pos()
frog.pos = 100, 370

GRAVITY = 0.5
frog.vy = 0

if gamepart == 1:
    for i in range(200):
        # Create a new block actor
        floor = Actor("floor.png")
        floor._surf = pygame.transform.scale(floor._surf, (50 + scroll_x, 50))
        floor._update_pos()
        # Position it (e.g., in a row)
        floor.x = i * 50
        floor.y = 470
        # Add it to our list
        floors.append(floor)

    for i in range(200):
        # Create a new block actor
        floor = Actor("floor.png")
        floor._surf = pygame.transform.scale(floor._surf, (50 + scroll_x, 50))
        floor._update_pos()
        # Position it (e.g., in a row)
        floor.x = i * 50
        floor.y = 430
        # Add it to our list
        floors.append(floor)

    # physics
    velocity = 0
    if gamepart == 1 or gamepart == 3:
        gravity = 0.5
        jump_strength = -12
    else:
        gravity = 0.2
        jump_strength = -5

    # game state
    game_over = False
    powered = False
    speed = 2

    on_ground = frog.y >= 500

    def draw():
        if gamepart == 1:
            screen.fill((135, 206, 235))
            frog.draw()
            for floor in floors:
                floor.draw()

        screen.draw.text(f"Score: {score}", (10, 10), color="black")

        if game_over:
            screen.clear()

    def update():
        global velocity, game_over, score, speed, frogpos, floorpos, scroll_x, floors
        if gamepart == 1:
            if game_over:
                return

            if on_ground:
                velocity = 0

            if not on_ground:
                velocity =0.5
                # apply gravity
                velocity += gravity
                frog.y += velocity

            # game over condition
            if frog.y > HEIGHT or frog.y < 0:
                game_over = True

            if keyboard.right:
                scroll_x -= 0.1
                for floor in floors:
                    floor.pos = ((floor.x + scroll_x), (floor.y))
            elif keyboard.left:
                scroll_x += 0.1
                for floor in floors:
                    floor.pos = ((floor.x + scroll_x), (floor.y))
            if keyboard.space and on_ground:
                jump()

    def jump():
        global velocity
        velocity = jump_strength


pgzrun.go()