#Credit to Charlie and his frog for the both frog images

from random import randint
import pygame
import pgzrun
from pgzero.actor import Actor

WIDTH=800
HEIGHT=600

frog=Actor("frog.png")
frog._surf = pygame.transform.scale(frog._surf, (100, 100))
frog._update_pos()
frog.pos=400, 300

platform=Actor("platform.png")
platform._surf = pygame.transform.scale(platform._surf, (100, 100))
platform._update_pos()
platform.pos=400, 500

if frog.colliderect(platform):
            frog.y = platform.y - 50  # sit on platform
            score += 1

            if frog.y > HEIGHT:
                game_over = True
up=False

game_over=False
score=0
number_of_updates=0

def draw():
    screen.blit("background.png", (0,0))
    if not game_over:
        frog.draw()
        platform.draw()
        screen.draw.text("Score: " + str(score), (720,5), color="black")

def on_mouse_down():
    global up
    up=True
    frog.y -= 50

def on_mouse_up():
    global up
    up=False

def jump():
    global frog_up
    if frog_up:
        frog.image="frog_jump.png"
        frog_up=False
    else:
        frog.image="frog.png"
        frog_up=True

def update():
    global game_over, score, number_of_updates
    if not game_over:
        if not up:
            frog.y += 5


        if number_of_updates == 9:
                jump()
                number_of_updates=0
        else:
            number_of_updates += 1

            number_of_updates = 0

        # if pole.right > 0:
        #     pole.x -= 2
        # else:
        #     pole.x = randint(800, 1600)
        #     score += 1
        #
        # if pole1.right > 0:
        #     pole1.x -= 2
        # else:
        #     pole.x = randint(800, 1600)
        #     score += 1

    # if bird.collidepoint(tree.x, tree.y):
    #     game_over=True

pgzrun.go()