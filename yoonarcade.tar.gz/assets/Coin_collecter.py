from random import randint
import pgzrun

width=400
height=400
score=0
game_over=False

fox=Actor('fox.png')
fox.pos=100,100

coin=Actor('coin.png')
coin.pos=200,200

coin1=Actor('coin.png')
coin1.pos=200,200

coin2=Actor('coin.png')
coin2.pos=200,200

def draw():
    screen.fill("green")
    fox.draw()
    coin.draw()
    coin1.draw()
    coin2.draw()
    screen.draw.text("Score: " + str(score), color="black", topleft=(10, 10))

    if game_over:
        screen.fill("pink")
        screen.draw.text("Final Score: " + str(score), color="black", topleft=(10, 10), fontsize=60)

def place_coin():
    coin.x = randint(50,700)
    coin.y = randint(45,500)

def place_coin1():
    coin1.x = randint(50,700)
    coin1.y = randint(45,500)

def place_coin2():
    coin2.x = randint(50,700)
    coin2.y = randint(45,500)

def time_up():
    global game_over
    game_over=True

def update():
    global score

    if keyboard.left:
        fox.x=fox.x-9
    elif keyboard.right:
        fox.x=fox.x+9
    elif keyboard.up:
        fox.y=fox.y-9
    elif keyboard.down:
        fox.y=fox.y+9

    coin_collected=fox.colliderect(coin)
    coin1_collected = fox.colliderect(coin1)
    coin2_collected = fox.colliderect(coin2)

    if coin_collected:
        score=score+20
        place_coin()

    if coin1_collected:
        score=score+20
        place_coin1()

    if coin2_collected:
        score=score+20
        place_coin2()

clock.schedule(time_up, 45.0)

place_coin()
place_coin1()
place_coin2()

pgzrun.go()