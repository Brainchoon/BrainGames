import os
import pygame

pygame.init()
pygame.font.init()

WIDTH = 550
HEIGHT = 600
screen_surface = pygame.display.set_mode((WIDTH, HEIGHT))

IMAGE_CACHE = {}


def get_image(asset_name):
    """Safely handles file paths, loading, and extensions for Pygbag."""
    if asset_name in IMAGE_CACHE:
        return IMAGE_CACHE[asset_name]

    base_name = os.path.splitext(asset_name)[0]
    possible_paths = [
        os.path.join("images", f"{base_name}.png"),
        os.path.join("images", f"{base_name}.jpg"),
        os.path.join("images", asset_name)
    ]

    for path in possible_paths:
        if os.path.exists(path):
            img = pygame.image.load(path).convert_alpha()
            IMAGE_CACHE[asset_name] = img
            return img

    fallback = pygame.Surface((32, 32), pygame.SRCALPHA)
    pygame.draw.rect(fallback, (255, 0, 255), (0, 0, 32, 32))
    return fallback


class Actor:
    def __init__(self, image_name, pos=(0, 0)):
        self._image_name = image_name
        self._raw_surf = get_image(image_name)
        self._surf_internal = self._raw_surf.copy()
        self.rect = self._surf_internal.get_rect()
        self._angle = 0
        self.pos = pos

    def _update_pos(self):
        current_topleft = self.rect.topleft
        if self._angle == 180:
            flipped_surf = pygame.transform.flip(self._surf_internal, False, True)
            self.rect = flipped_surf.get_rect()
        elif self._angle != 0:
            rotated_surf = pygame.transform.rotate(self._surf_internal, self._angle)
            self.rect = rotated_surf.get_rect()
        else:
            self.rect = self._surf_internal.get_rect()
        self.rect.topleft = current_topleft

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, value):
        self._angle = value
        self._update_pos()

    @property
    def _surf(self):
        return self._surf_internal

    @_surf.setter
    def _surf(self, new_surface):
        self._surf_internal = new_surface
        self._update_pos()

    @property
    def pos(self):
        return self.rect.topleft

    @pos.setter
    def pos(self, value):
        self.rect.topleft = value

    @property
    def x(self):
        return self.rect.x

    @x.setter
    def x(self, value):
        self.rect.x = value

    @property
    def y(self):
        return self.rect.y

    @y.setter
    def y(self, value):
        self.rect.y = value

    @property
    def left(self):
        return self.rect.left

    @left.setter
    def left(self, value):
        self.rect.left = value

    @property
    def right(self):
        return self.rect.right

    @right.setter
    def right(self, value):
        self.rect.right = value

    @property
    def top(self):
        return self.rect.top

    @top.setter
    def top(self, value):
        self.rect.top = value

    @property
    def bottom(self):
        return self.rect.bottom

    @bottom.setter
    def bottom(self, value):
        self.rect.bottom = value

    @property
    def height(self):
        return self.rect.height

    @property
    def width(self):
        return self.rect.width

    def colliderect(self, other):
        return self.rect.colliderect(other.rect)

    def draw(self):
        if self._angle == 180:
            render_surf = pygame.transform.flip(self._surf_internal, False, True)
            screen_surface.blit(render_surf, self.rect)
        elif self._angle != 0:
            render_surf = pygame.transform.rotate(self._surf_internal, self._angle)
            screen_surface.blit(render_surf, self.rect)
        else:
            screen_surface.blit(self._surf_internal, self.rect)


class TextDraw:
    def text(self, text, pos=None, center=None, fontsize=32, color="black"):
        try:
            font = pygame.font.SysFont("Arial", fontsize, bold=True)
        except:
            font = pygame.font.Font(None, fontsize)

        color_rgb = (0, 0, 0) if color == "black" else (255, 255, 255)
        lines = str(text).split('\n')
        y_offset = 0

        for line in lines:
            text_surf = font.render(line, True, color_rgb)
            text_rect = text_surf.get_rect()

            if center:
                text_rect.center = (center[0], center[1] + y_offset)
            elif pos:
                if pos[0] > WIDTH - 120:
                    text_rect.topright = (WIDTH - 15, pos[1] + y_offset)
                else:
                    text_rect.topleft = (pos[0], pos[1] + y_offset)
            else:
                text_rect.topleft = (0, 0 + y_offset)

            screen_surface.blit(text_surf, text_rect)
            y_offset += text_rect.height


class ScreenBridge:
    def __init__(self):
        self.draw = TextDraw()

    def blit(self, asset, pos):
        img_surface = get_image(asset)
        screen_surface.blit(img_surface, pos)

    def clear(self):
        screen_surface.fill((0, 0, 0))


screen = ScreenBridge()


class KeysObject:
    SPACE = pygame.K_SPACE


keys = KeysObject()

