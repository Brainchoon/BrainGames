import asyncio
import builtins
import pygame
import sys

# 1. Initialize the specialized web bridge environment
import pgz_web_bridge

game_contents_file = "Flappybird.py"

# 2. Inject Pygame Zero variables globally so game.py finds them automatically
builtins.Actor = pgz_web_bridge.Actor
builtins.screen = pgz_web_bridge.screen
builtins.keys = pgz_web_bridge.keys
builtins.pygame = pygame  # In case game.py uses pygame.transform

# 3. Read and execute the clean game file inside the main context
with open(game_contents_file, "r") as f:
    game_code = f.read()

# Execute game.py line-by-line to extract functions into our global scope
exec(game_code, globals())


# ====================================================================
# WEB RUNTIME EVENT LOOP EXECUTION
# ====================================================================
async def main_loop():
    clock = pygame.time.Clock()

    # Initialize the game's setup state
    if 'setup' in globals():
        globals()['setup']()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            elif event.type == pygame.KEYDOWN:
                if 'on_key_down' in globals():
                    globals()['on_key_down'](event.key)
            elif event.type == pygame.KEYUP:
                if 'on_key_up' in globals():
                    globals()['on_key_up'](event.key)

        # Step updates and screen redraw loops
        if 'update' in globals():
            globals()['update']()
        if 'draw' in globals():
            globals()['draw']()

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


asyncio.run(main_loop())

